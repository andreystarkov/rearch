export const isAuth = (state) => {
  return state.auth.get('auth')
}
