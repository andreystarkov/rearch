import {
  EVENT_REQUEST_STATE,
  EVENT_SUCCESS_STATE,
  EVENT_FAILURE_STATE
} from '../../EventStates'

export const userRegisterRequest = (state) => state.merge({
  Register: { ...EVENT_REQUEST_STATE }
})

export const userRegisterSuccess = (state, { temperature }) => state.merge({
  auth: true,
  Register: { ...EVENT_SUCCESS_STATE }
})

export const userRegisterFailure = (state, { error }) => state.merge({
  auth: false,
  Register: {
    ...EVENT_FAILURE_STATE,
    errorMessage: error
  }
})
